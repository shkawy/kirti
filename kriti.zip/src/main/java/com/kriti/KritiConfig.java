package com.kriti;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class KritiConfig {
    public static String apiKey = "";
    public static String model = "claude-haiku-5-5";

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("kriti.json");
        try {
            if (!Files.exists(file)) {
                JsonObject o = new JsonObject();
                o.addProperty("apiKey", "");
                o.addProperty("model", model);
                Files.writeString(file, new Gson().newBuilder().setPrettyPrinting().create().toJson(o),
                        StandardCharsets.UTF_8);
                return;
            }
            JsonObject o = new Gson().fromJson(Files.readString(file, StandardCharsets.UTF_8), JsonObject.class);
            if (o.has("apiKey")) apiKey = o.get("apiKey").getAsString().trim();
            if (o.has("model")) model = o.get("model").getAsString().trim();
        } catch (Exception e) {
            System.err.println("[Kriti] could not read config: " + e);
        }
    }
}
